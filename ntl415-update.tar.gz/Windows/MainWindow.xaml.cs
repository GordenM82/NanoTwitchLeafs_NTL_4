﻿using Hardcodet.Wpf.TaskbarNotification;
using log4net;
using log4net.Core;
using log4net.Repository.Hierarchy;
using NanoTwitchLeafs.Colors;
using NanoTwitchLeafs.Controller;
using NanoTwitchLeafs.Objects;
using NanoTwitchLeafs.Repositories;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using NanoTwitchLeafs.Enums;
using TwitchLib.EventSub.Websockets.Extensions;
using Application = System.Windows.Application;
using ComboBox = System.Windows.Controls.ComboBox;
using ListBox = System.Windows.Controls.ListBox;
using MessageBox = System.Windows.MessageBox;

namespace NanoTwitchLeafs.Windows
{
	/// <summary>
	/// Interaction logic for MainWindow.xaml
	/// </summary>
	public partial class MainWindow : Window
	{
		private readonly List<string> _twitchChat = new List<string>();
		private static readonly ObservableCollection<ConsoleLogEntry> Console = new ObservableCollection<ConsoleLogEntry>();
		private LoadingWindow _loadingWindow;

		private readonly ILog _logger = LogManager.GetLogger(typeof(MainWindow));

		private readonly AppSettingsController _appSettingsController;
		private readonly AppSettings _appSettings;
		private bool _appearanceControlsReady;
		private readonly TwitchController _twitchController;
		private readonly NanoController _nanoController;
		private readonly CommandRepository _commandRepository;
		private readonly StreamlabsController _streamlabsController;
		private readonly StreamElementsController _streamElementsController;
		private readonly TriggerLogicController _triggerLogicController;
		private readonly HypeRateIOController _hypeRatecontroller;
		private readonly UpdateController _updateController;
		private bool _consoleAutoScroll = true;
		private ICollectionView _consoleView;
		private readonly DispatcherTimer _toastTimer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(3) };
		private readonly TaskbarIcon _tbi = new TaskbarIcon();
		private readonly TwitchEventSubController _twitchEventSubController;
		private bool _initialWindowActivationCompleted;
		private TriggerWindow _embeddedTriggerManager;
		private AppInfoWindow _embeddedAppInfo;
		private Responses _embeddedResponses;
		private DevicesInfoWindow _embeddedDevices;
		private DeviceGroupsWindow _embeddedDeviceGroups;
		private int _currentPage = -1;
		private int _helpReturnPage = -1;
		private Action _helpReturnAction;
		private bool _helpReturnFollowsSelectedTopic;
		private int _embeddedReturnPage = -1;
		private bool _settingsTrackingReady;
		private bool _settingsDirty;
		private bool _shutdownCompleted;

		public enum HelpTopic
		{
			General,
			Nano,
			Trigger,
			ChatResponses,
			Devices,
			Twitch,
			Integrations,
			StreamElements
		}
		private static string DisplayVersion => typeof(AppInfoWindow).Assembly.GetName().Version.ToString(3);
		private static string VersionBadgeText => DisplayVersion;

		private static void TryPrepareLegacyMigration()
		{
#if NTL4
			if (File.Exists(Constants.SETTINGS_PATH) ||
				File.Exists(Constants.TRIGGERS_PATH) ||
				File.Exists(Constants.LEGACY_MIGRATION_ACCEPTED_PATH) ||
				File.Exists(Constants.LEGACY_MIGRATION_COMPLETED_PATH))
			{
				return;
			}

			bool hasLegacySettings = File.Exists(Constants.LEGACY_SETTINGS_PATH);
			bool hasLegacyTriggers = File.Exists(Constants.LEGACY_DATABASE_PATH);
			if (!hasLegacySettings && !hasLegacyTriggers)
			{
				return;
			}

			var startupCulture = System.Globalization.CultureInfo.CurrentUICulture.TwoLetterISOLanguageName
				.Equals("de", StringComparison.OrdinalIgnoreCase)
				? System.Globalization.CultureInfo.GetCultureInfo("de-DE")
				: System.Globalization.CultureInfo.GetCultureInfo("en-US");
			string message = Properties.Resources.ResourceManager.GetString(
				"Code_Main_MessageBox_LegacyMigration_Text", startupCulture);
			string title = Properties.Resources.ResourceManager.GetString(
				"Code_Main_MessageBox_LegacyMigration_Title", startupCulture);

			if (MessageBox.Show(message, title, MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes)
			{
				return;
			}

			try
			{
				Directory.CreateDirectory(Constants.PROGRAMFILESFOLDER_PATH);
				Directory.CreateDirectory(Constants.LEGACY_MIGRATION_BACKUP_PATH);

				if (hasLegacySettings)
				{
					File.Copy(Constants.LEGACY_SETTINGS_PATH,
						Path.Combine(Constants.LEGACY_MIGRATION_BACKUP_PATH, "settings.txt"), true);
					File.Copy(Constants.LEGACY_SETTINGS_PATH, Constants.SETTINGS_PATH, false);
				}

				if (hasLegacyTriggers)
				{
					File.Copy(Constants.LEGACY_DATABASE_PATH,
						Path.Combine(Constants.LEGACY_MIGRATION_BACKUP_PATH, "nanotwitchleafs.sqlite"), true);
				}

				File.WriteAllText(Constants.LEGACY_MIGRATION_ACCEPTED_PATH, DateTime.UtcNow.ToString("O"));
			}
			catch (Exception exception)
			{
				MessageBox.Show(
					Properties.Resources.ResourceManager.GetString(
						"Code_Main_MessageBox_LegacyMigration_Error", startupCulture) + "\n\n" + exception.Message,
					title, MessageBoxButton.OK, MessageBoxImage.Warning);
			}
#endif
		}

		#region Init

		public MainWindow()
		{
			TryPrepareLegacyMigration();

			// Load settings for Language
			_appSettingsController = new AppSettingsController();
			_appSettings = _appSettingsController.LoadSettings();
			_appSettings.StreamElements ??= new StreamElementsSettings();
			_appSettings.Blacklist ??= new List<string>();

			// Set Language before Init of Window
			Constants.SetCultureInfo(_appSettings.Language);
			ThemeManager.Apply(_appSettings.Theme, _appSettings.AccentColor);

			// Init Window and Controls
			InitializeComponent();
			versionBadge_TextBlock.Text = VersionBadgeText;
			_toastTimer.Tick += (_, _) => { _toastTimer.Stop(); toast_Border.Visibility = Visibility.Collapsed; };


#if !DEBUG
            InstanceCheck();
#endif

			_tbi.Icon = new System.Drawing.Icon(@"nanotwitchleafs.ico");
			_tbi.TrayMouseDoubleClick += NotifyIcon_Click;
			_tbi.TrayBalloonTipClicked += NotifyIcon_Click;
			_tbi.PopupActivation = PopupActivationMode.LeftOrDoubleClick;
			_tbi.ContextMenu = new ContextMenu();
			_tbi.MenuActivation = PopupActivationMode.RightClick;
			var itemShow = new MenuItem() { Header = Properties.Resources.Window_NotifyContextMenu_Button_Show_Text };
			itemShow.Click += ItemShow_Click;
			_tbi.ContextMenu.Items.Add(itemShow);
			var itemExit = new MenuItem() { Header = Properties.Resources.Window_Devices_Button_Close };
			itemExit.Click += ItemExit_Click;
			_tbi.ContextMenu.Items.Add(itemExit);
			
			var appender = new NanoTwitchLeafsAppender();
			appender.OnMessageLogged += Logger_OnAppenderMessage;
			((IAppenderAttachable)((Hierarchy)LogManager.GetRepository()).Root).AddAppender(appender);

			// Initialize Controller
#if RELEASE
            _logger.Info($"Start Program - Version: {DisplayVersion}");
            _tbi.ToolTipText = $"NanoTwitchLeafs {DisplayVersion}";
#endif
#if BETA
            _logger.Info($"Start Program - Version: {typeof(AppInfoWindow).Assembly.GetName().Version} - BETA");
            _tbi.ToolTipText = $"NanoTwitchLeafs {typeof(AppInfoWindow).Assembly.GetName().Version} - BETA";
#endif
#if DEBUG
			_logger.Info($"Start Program - Version: {typeof(AppInfoWindow).Assembly.GetName().Version} - DEBUG");
			_tbi.ToolTipText = $"NanoTwitchLeafs {typeof(AppInfoWindow).Assembly.GetName().Version} - DEBUG";
#endif
			AppDomain.CurrentDomain.UnhandledException += (o, args) =>
			{
				if (args.IsTerminating)
				{
					_appSettings.AutoConnect = false;
					_appSettingsController.SaveSettings(_appSettings);
					_logger.Info("Auto Connect disabled cause of Terminating Exception");
					MessageBox.Show(Properties.Resources.General_MessageBox_GeneralErrorCrash_Text, Properties.Resources.General_MessageBox_Error_Title, MessageBoxButton.OK, MessageBoxImage.Error);
				}
				else
				{
					MessageBox.Show(Properties.Resources.General_MessageBox_GeneralError_Text, Properties.Resources.General_MessageBox_Error_Title, MessageBoxButton.OK, MessageBoxImage.Error);
				}
				_logger.Error($"Exception terminated Program: {args.IsTerminating}");
				_logger.Error(args.ExceptionObject);
			};

			if (_appSettings.DebugEnabled)
				SetLogLevel(Level.Debug);
			_logger.Info("Initialize Update Controller");
			_updateController = new UpdateController(_appSettings);

			_logger.Info("Initialize Twitch Controller");
			_twitchController = new TwitchController(_appSettingsController);
			_twitchController.OnChatMessageReceived += _twitchController_OnChatMessageReceived;
			_twitchController.OnCallLoadingWindow += OnCallLoadingWindow;
			_twitchController.OnChatConnectionChanged += TwitchController_OnChatConnectionChanged;
			_twitchController.OnChatConnectionFailed += TwitchController_OnChatConnectionFailed;

			_logger.Info("Initialize Dependency Injection for TwitchEventSubController");

			var serviceCollection = new ServiceCollection();
			serviceCollection.AddTwitchLibEventSubWebsockets();
			serviceCollection.AddLogging(config =>
			{
				config.ClearProviders();
				//config.AddLog4Net("log4net.config");
				//config.AddConsole();
			});
			
			var serviceProvider = serviceCollection.BuildServiceProvider();
			
			_logger.Info("Initialize TwitchEventSub Controller");
			_twitchEventSubController = new TwitchEventSubController(serviceProvider, _appSettings);
			_twitchController.EventSubController = _twitchEventSubController;
			
			_logger.Info("Initialize Nano Controller");
			_nanoController = new NanoController(_appSettings);

			_logger.Info("Initialize Trigger Command Repository");
#if NTL4
			_commandRepository = new CommandRepository(CreateNtl4TriggerStore());
#else
			_commandRepository = new CommandRepository(new DatabaseController<TriggerSetting>(Constants.DATABASE_PATH));
#endif

			_logger.Info("Initialize HypeRate Controller");
			_hypeRatecontroller = new HypeRateIOController(_appSettings);
			_hypeRatecontroller.OnHeartRateRecieved += _hypeRatecontroller_OnHeartRateRecieved;
			_hypeRatecontroller.OnHypeRateConnected += _hypeRatecontroller_OnHypeRateConnected;
			_hypeRatecontroller.OnHypeRateDisconnected += _hypeRatecontroller_OnHypeRateDisconnected;

			_logger.Info("Initialize Streamlabs Controller");
			_streamlabsController = new StreamlabsController(_appSettings);
			_logger.Info("Initialize StreamElements Controller");
			_streamElementsController = new StreamElementsController(_appSettings);
			_streamElementsController.ConnectionStateChanged += StreamElementsController_ConnectionStateChanged;

			try
			{
				//This has to be Last!
				_logger.Info("Initialize Trigger Logic Controller");
				_triggerLogicController = new TriggerLogicController(_appSettings, _twitchController, _commandRepository, _nanoController, _twitchEventSubController, _streamlabsController, _streamElementsController, _hypeRatecontroller);
			}
			catch (Exception ex)
			{
#if NTL4
				MessageBox.Show(
					Properties.Resources.ResourceManager.GetString("Code_Main_MessageBox_TriggerInitialization_Error") + $"\n\n{ex.Message}",
					Properties.Resources.General_MessageBox_Error_Title,
					MessageBoxButton.OK,
					MessageBoxImage.Error);
				_logger.Error("Could not initialize Trigger Logic Controller.");
#else
				MessageBox.Show(Properties.Resources.General_MessageBox_WMPinstalled_Error_Text, Properties.Resources.General_MessageBox_Error_Title, MessageBoxButton.OK, MessageBoxImage.Error);
				_logger.Error("Could not initialize Trigger Logic Controller. Check Windows Media Player!");
#endif
				_logger.Error(ex.Message, ex);
			}

			
			// Initialize Data
			_logger.Info("Initialize Data");
			InitializeData();
			
#if BETA
            MessageBox.Show(Properties.Resources.Code_Main_MessageBox_Beta, Properties.Resources.Code_Main_MessageBox_BetaTitle);
#endif
			// attach property change event to configuration object and its subsequent elements if any derived NotifyObject
			// Main-window controls are tracked explicitly below. Runtime updates
			// (connections, refreshed devices, tokens and window placement) must not
			// make a freshly started application appear modified.
			ConfigureSettingsChangeTracking();
			_settingsTrackingReady = true;

			if (_appSettings.AutoIpRefresh)
			{
				_logger.Info($"Refreshing Ip-Address of {_appSettings.NanoSettings.NanoLeafDevices.Count} Devices.");
#pragma warning disable 4014
				_nanoController.UpdateAllNanoleafDevices();
#pragma warning restore 4014
			}

			if (_appSettings.AutoConnect)
			{
				_logger.Info("Preparing for Auto Connect ...");
				AutoConnect();
			}
			else
			{
				_logger.Info("Auto Connect not enabled!");
			}
			if (_appSettings.StreamElements.Enabled && _appSettings.StreamElements.AutoConnect && !string.IsNullOrWhiteSpace(_appSettings.StreamElements.Token))
			{
				_logger.Info("[Auto Connection] Try to connect to StreamElements ...");
				_ = _streamElementsController.ConnectAsync();
			}

		}

		private void ItemExit_Click(object sender, RoutedEventArgs e)
		{
#if !NTL4
			_analyticsController.SendPing(PingType.Stop, "Shutting down");
#endif
			Close();
		}

		private void Main_Window_Loaded(object sender, RoutedEventArgs e)
		{
			if (_initialWindowActivationCompleted)
				return;

			_initialWindowActivationCompleted = true;
			RestoreWindowPlacement();
			ShowInTaskbar = true;
			Show();
			Activate();
			// Briefly making the window topmost is the reliable WPF way to bring a
			// manually started application in front of Explorer/build windows.
			Topmost = true;
			Topmost = false;
			Focus();
		}

		private void RestoreWindowPlacement()
		{
			double requestedWidth = _appSettings.WindowWidth >= MinWidth ? _appSettings.WindowWidth : Width;
			double requestedHeight = _appSettings.WindowHeight >= MinHeight ? _appSettings.WindowHeight : Height;
			double requestedLeft = _appSettings.WindowLeft != 0 || _appSettings.WindowTop != 0 ? _appSettings.WindowLeft : Left;
			double requestedTop = _appSettings.WindowLeft != 0 || _appSettings.WindowTop != 0 ? _appSettings.WindowTop : Top;
			Rect placement = WindowPlacementService.RestoreMainWindow(this, new Rect(requestedLeft, requestedTop, requestedWidth, requestedHeight), out string monitorDescription);
			Width = placement.Width;
			Height = placement.Height;
			Left = placement.Left;
			Top = placement.Top;
			_logger.Info($"Window placement: {placement.Width:0}x{placement.Height:0} at {placement.Left:0},{placement.Top:0}; {monitorDescription}.");
			WindowState = _appSettings.WindowMaximized ? WindowState.Maximized : WindowState.Normal;
		}

		private void SaveWindowPlacement()
		{
			System.Windows.Rect bounds = WindowState == WindowState.Normal ? new System.Windows.Rect(Left, Top, Width, Height) : RestoreBounds;
			_appSettings.WindowLeft = bounds.Left;
			_appSettings.WindowTop = bounds.Top;
			_appSettings.WindowWidth = bounds.Width;
			_appSettings.WindowHeight = bounds.Height;
			_appSettings.WindowMaximized = WindowState == WindowState.Maximized;
		}

		private void ItemShow_Click(object sender, RoutedEventArgs e)
		{
			if (WindowState == WindowState.Normal)
			{
				this.Activate();
			}
			else
			{
				this.Show();
				this.WindowState = WindowState.Normal;
			}
		}

		public async Task InitializeAsync()
		{
			// Init for early Stuff
			// Was used for License Controller
			// Now empty
		}

		private void OnCallLoadingWindow(bool state)
		{
			Application.Current.Dispatcher.Invoke(() =>
			{
				if (state)
				{
					if (_loadingWindow?.IsVisible == true)
						return;
					_loadingWindow = new LoadingWindow(_appSettings.Language);
					WindowPlacementService.PrepareOwnedWindow(_loadingWindow, Main_Window);
					_loadingWindow.Show();
				}
				else
				{
					if (_loadingWindow == null || !_loadingWindow.IsVisible)
						return;

					_loadingWindow.Close();
				}
			});
		}

		private void InstanceCheck()
		{
			var process = Process.GetProcessesByName(Path.GetFileNameWithoutExtension(System.Reflection.Assembly.GetEntryAssembly()?.Location));
			if (process.Count() > 1)
			{
				MessageBox.Show(Properties.Resources.Code_Main_MessageBox_InstanceCheck, Properties.Resources.General_MessageBox_Error_Title);
				Process.GetCurrentProcess().Kill();
			}
		}

		private void NotifyIcon_Click(object sender, EventArgs e)
		{
			this.Show();
			this.WindowState = WindowState.Normal;
		}

		private void MainWindow_PreviewKeyDown(object sender, KeyEventArgs e)
		{
			if (e.Key == Key.Escape && blocklistPanel.Visibility == Visibility.Visible)
			{
				ShowMainPage(0);
				e.Handled = true;
			}
			else if (e.Key == Key.Escape && helpPanel.Visibility == Visibility.Visible)
			{
				HelpBack_Button_Click(sender, e);
				e.Handled = true;
			}
			else if (e.Key == Key.Escape && (triggerManager_Host.Visibility == Visibility.Visible || appInfo_Host.Visibility == Visibility.Visible))
			{
				ShowMainPage(_embeddedReturnPage is >= -1 and <= 5 ? _embeddedReturnPage : -1);
				e.Handled = true;
			}
			else if (e.Key == Key.Escape && management_Host.Visibility == Visibility.Visible)
			{
				ShowMainPage(_currentPage);
				e.Handled = true;
			}
			else if (e.Key == Key.F && Keyboard.Modifiers.HasFlag(ModifierKeys.Control) &&
				chatconsole_TabControl.Visibility == Visibility.Visible && chatconsole_TabControl.SelectedIndex == 1)
			{
				consoleSearch_TextBox.Focus();
				consoleSearch_TextBox.SelectAll();
				e.Handled = true;
			}
		}

		private void _appSettings_PropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
		{
			if (_chatConnectionInProgress)
				return;

			// Runtime connection data is refreshed automatically and persisted by the
			// corresponding connection path. It is not an unsaved user preference.
			if (sender is NanoLeafDevice && e.PropertyName == nameof(NanoLeafDevice.NanoleafControllerInfo))
				return;
			if (sender is NanoSettings && e.PropertyName == nameof(NanoSettings.NanoLeafDevices))
				return;

			// Auth objects are only replaced by account management or automatic token
			// refresh. Both paths persist them immediately, so they are not user edits.
			if (e.PropertyName is nameof(AppSettings.BotAuthObject) or nameof(AppSettings.BroadcasterAuthObject))
				return;

			if (!Dispatcher.CheckAccess())
			{
				Dispatcher.BeginInvoke(new Action(MarkSettingsDirty));
				return;
			}
			MarkSettingsDirty();
		}

		#endregion

		#region Methods

		private void InitializeData()
		{
			try
			{
				// Fill Language Combobox with available Languages
				var languages = new List<ComboBoxItem>
				{
					new ComboBoxItem { Content = "Deutsch", Tag = "de-DE" },
					new ComboBoxItem { Content = "English – Englisch", Tag = "en-US" },
					new ComboBoxItem { Content = "Dansk – Dänisch", Tag = "da-DK" },
					new ComboBoxItem { Content = "Español – Spanisch", Tag = "es-ES" },
					new ComboBoxItem { Content = "Français – Französisch", Tag = "fr-FR" },
					new ComboBoxItem { Content = "Italiano – Italienisch", Tag = "it-IT" },
					new ComboBoxItem { Content = "Nederlands – Niederländisch", Tag = "nl-NL" },
					new ComboBoxItem { Content = "Polski – Polnisch", Tag = "pl-PL" },
					new ComboBoxItem { Content = "Português (Brasil) – Portugiesisch", Tag = "pt-BR" },
					new ComboBoxItem { Content = "Slovenčina – Slowakisch", Tag = "sk-SK" },
					new ComboBoxItem { Content = "Русский – Russisch", Tag = "ru-RU" }
				};

					language_Combobox.ItemsSource = languages;
				InitializeAppearanceControls();
				InitializeP22Texts();
				InitializeUpdateSourceControls();
				language_Combobox.SelectedItem = languages.FirstOrDefault(item =>
					string.Equals(item.Tag?.ToString(), _appSettings.Language, StringComparison.OrdinalIgnoreCase))
					?? languages[1];

				twitchChat_ListBox.ItemsSource = _twitchChat;
				chatStatus_TextBlock.Text = Text("P411_Chat_Disconnected");
				_consoleView = CollectionViewSource.GetDefaultView(Console);
				_consoleView.Filter = ConsoleEntryMatchesFilter;
				console_ListBox.ItemsSource = _consoleView;
				consoleLevelFilter_ComboBox.SelectedIndex = 0;
				UpdateConsoleResultCount();

				// Bot Settings
				whisperMode_Checkbox.IsChecked = _appSettings.WhisperMode;
				commandPrefix_TextBox.Text = _appSettings.CommandPrefix;
				response_CheckBox.IsChecked = _appSettings.ChatResponse;

				// Nano Settings
				nanoCmd_Button.IsEnabled = _appSettings.NanoSettings.TriggerEnabled;
				nanoCmd_Checkbox.IsChecked = _appSettings.NanoSettings.TriggerEnabled;
				nanoCooldown_Checkbox.IsChecked = _appSettings.NanoSettings.CooldownEnabled;
				nanoCooldownIgnore_Checkbox.IsEnabled = _appSettings.NanoSettings.CooldownIgnore;
				nanoCooldown_TextBox.Text = _appSettings.NanoSettings.Cooldown.ToString();
				commandRestore_CheckBox.IsChecked = _appSettings.NanoSettings.ChangeBackOnCommand;
				keywordRestore_Checkbox.IsChecked = _appSettings.NanoSettings.ChangeBackOnKeyword;

				// App Settings
				autoIPRefresh_Checkbox.IsChecked = _appSettings.AutoIpRefresh;
				debugCmd_Checkbox.IsChecked = _appSettings.DebugEnabled;
				blacklist_CheckBox.IsChecked = _appSettings.BlacklistEnabled;
				RefreshBlocklist();

				DebugCmd_Checkbox_Click(this, null);

				// HypeRate
				hypeRateId_Textbox.Text = _appSettings.HypeRateId;

				// Twitch Link Settings
				if (_appSettings.BroadcasterAvatarUrl != null && _appSettings.BroadcasterAuthObject != null)
				{
					TwitchLinkAvatar_Image.Source = new BitmapImage(_appSettings.BroadcasterAvatarUrl);
					TwitchLink_Label.Content = Properties.Resources.Window_Main_Tabs_TwitchLogin_AccountLabel_Text2 + _appSettings.ChannelName;
					ConnectTwitchAccount_Button.IsEnabled = false;
					DisconnectTwitchAccount_Button.IsEnabled = true;
					ConnectChat_Button.IsEnabled = true;
				}

				// Streamlabs
				if (_appSettings.StreamlabsInformation.StreamlabsAToken != null && !string.IsNullOrWhiteSpace(_appSettings.StreamlabsInformation.StreamlabsAToken))
				{
					Streamlabs_Image.Source = TwitchLinkAvatar_Image.Source;
					StreamlabsUnlink_Button.IsEnabled = true;
					StreamlabsLink_Button.IsEnabled = false;
					StreamlabsConnectButton.IsEnabled = true;
					StreamlabsInfo_TextBlock.Text = $"Connected to Account {_appSettings.ChannelName}.";
				}
				StreamlabsClientId_Textbox.Text = _appSettings.StreamlabsClientId;
				StreamlabsClientSecret_Textbox.Password = _appSettings.StreamlabsClientSecret;
				HypeRateApiKey_Textbox.Password = _appSettings.HypeRateApiKey;
				streamElementsEnabled_CheckBox.IsChecked = _appSettings.StreamElements.Enabled;
				streamElementsAutoConnect_CheckBox.IsChecked = _appSettings.StreamElements.AutoConnect;
				streamElementsToken_PasswordBox.Password = _appSettings.StreamElements.Token ?? string.Empty;
				SelectComboBoxItem(streamElementsTokenType_ComboBox, _appSettings.StreamElements.TokenType ?? "jwt");
				UpdateStreamElementsStatus(_streamElementsController.IsConnected, _appSettings.StreamElements.LastConnectionError);

				ChangeEnabledUi();
			}
			catch (Exception ex)
			{
				_logger.Error("Could not fill Controls. Settings Corrupt. Generating blank Settings instead.");
				_logger.Error(ex.Message, ex);
				_appSettingsController.SaveSettings(new AppSettings());
				_appSettingsController.LoadSettings();
				InitializeData();
			}
		}

		private void CheckForUpdate()
		{
			_updateController.CheckForUpdates();
		}

		private void InitializeUpdateSourceControls()
		{
			updateSourceLabel_TextBlock.Text = Text("P415_Update_SourceLabel");
			updateSourceAll_Item.Content = Text("P415_Update_SourceAll");
			updateSourceNtl4_Item.Content = Text("P415_Update_SourceNtl4");
			updateSourceOriginal_Item.Content = Text("P415_Update_SourceOriginal");
			SelectComboBoxItem(updateSource_ComboBox, _appSettings.UpdateSource);
		}

		private void Logger_OnAppenderMessage(Level level, DateTime logTime, string message)
		{
			Logger_OnMessage(level?.Name ?? "INFO", $"[{logTime.ToShortTimeString()}][{level}] {message}");
		}

		private void Logger_OnMessage(string level, string message)
		{
			if (console_ListBox == null)
				return;

			console_ListBox.Dispatcher.Invoke(() =>
			{
				Console.Add(new ConsoleLogEntry { Level = NormalizeLogLevel(level), Message = message });
				_consoleView?.Refresh();
				UpdateConsoleResultCount();
				if (_consoleAutoScroll)
					UpdateScrollBar(console_ListBox);
			});
		}

		private static string NormalizeLogLevel(string level)
		{
			if (string.Equals(level, "FATAL", StringComparison.OrdinalIgnoreCase)) return "ERROR";
			if (string.Equals(level, "WARNING", StringComparison.OrdinalIgnoreCase)) return "WARN";
			return string.IsNullOrWhiteSpace(level) ? "INFO" : level.ToUpperInvariant();
		}

		private void ConfigureSettingsChangeTracking()
		{
			foreach (TextBox textBox in new[] { commandPrefix_TextBox, nanoCooldown_TextBox, hypeRateId_Textbox, StreamlabsClientId_Textbox })
				textBox.TextChanged += SettingsControl_Changed;
			foreach (PasswordBox passwordBox in new[] { StreamlabsClientSecret_Textbox, HypeRateApiKey_Textbox, streamElementsToken_PasswordBox })
				passwordBox.PasswordChanged += SettingsControl_Changed;
			foreach (CheckBox checkBox in new[]
			{
				autoConnect_Checkbox, response_CheckBox, whisperMode_Checkbox, nanoCmd_Checkbox,
				nanoCooldown_Checkbox, nanoCooldownIgnore_Checkbox, commandRestore_CheckBox,
				keywordRestore_Checkbox, autoIPRefresh_Checkbox, debugCmd_Checkbox,
				streamElementsEnabled_CheckBox, streamElementsAutoConnect_CheckBox
			}) checkBox.Click += SettingsControl_Changed;
			streamElementsTokenType_ComboBox.SelectionChanged += SettingsControl_Changed;
			updateSource_ComboBox.SelectionChanged += SettingsControl_Changed;
		}

		private void SettingsControl_Changed(object sender, RoutedEventArgs e) => MarkSettingsDirty();

		private void MarkSettingsDirty()
		{
			if (!_settingsTrackingReady || _settingsDirty) return;
			_settingsDirty = true;
			unsavedChanges_TextBlock.Text = Text("P25_Unsaved");
			unsavedChanges_TextBlock.Visibility = Visibility.Visible;
			Save_Button.ToolTip = Text("P25_Unsaved");
		}

		private void MarkSettingsSaved()
		{
			_settingsDirty = false;
			unsavedChanges_TextBlock.Visibility = Visibility.Collapsed;
			Save_Button.ToolTip = null;
		}

		private bool _chatConnectionInProgress;

		private void ShowToast(string message)
		{
			if (string.IsNullOrWhiteSpace(message)) return;
			toast_TextBlock.Text = message;
			toast_Border.Visibility = Visibility.Visible;
			_toastTimer.Stop();
			_toastTimer.Start();
		}

		#endregion

		#region UI Logic

		private void blacklist_CheckBox_Click(object sender, RoutedEventArgs e)
		{
			if (blacklist_CheckBox.IsChecked == true)
			{
				_appSettings.BlacklistEnabled = true;
				_logger.Info("Blacklist enabled!");
			}
			else if (blacklist_CheckBox.IsChecked == false)
			{
				_appSettings.BlacklistEnabled = false;
				_logger.Info("Blacklist disabled!");
			}
			_appSettingsController.SaveSettings(_appSettings);
			RefreshBlocklistSummary();
		}

		private void CheckForUpdate_Button_Click(object sender, RoutedEventArgs e)
		{
			CheckForUpdate();
		}

		private async void LoadEffects_Button_Click(object sender, RoutedEventArgs e)
		{
			if (_appSettings.NanoSettings.NanoLeafDevices.Count < 1)
			{
				_logger.Error(Properties.Resources.Code_Main_MessageBox_NoDevice);
				MessageBox.Show(Properties.Resources.Code_Main_MessageBox_NoDevice, Properties.Resources.General_MessageBox_Error_Title, MessageBoxButton.OK, MessageBoxImage.Error);
				return;
			}

			List<string> effects = await _nanoController.GetEffectList(_appSettings.NanoSettings.NanoLeafDevices[0]);

			Effects_ComboBox.ItemsSource = effects;
		}

		private async void SetBaseEffect_Button_Click(object sender, RoutedEventArgs e)
		{
			if (Effects_ComboBox.SelectedItem == null)
			{
				return;
			}

			if (string.IsNullOrWhiteSpace(Effects_ComboBox.SelectedItem.ToString()))
			{
				_logger.Warn(Properties.Resources.Code_Main_MessageBox_SelectEffect);
				MessageBox.Show(Properties.Resources.Code_Main_MessageBox_SelectEffect, Properties.Resources.General_MessageBox_Error_Title, MessageBoxButton.OK, MessageBoxImage.Warning);
				return;
			}

			foreach (var device in _appSettings.NanoSettings.NanoLeafDevices)
			{
				await _nanoController.SetEffect(device, Effects_ComboBox.SelectedItem.ToString());
				_logger.Info($"Set {Effects_ComboBox.SelectedItem} to Device {device.PublicName}");
			}
		}

		private void language_Combobox_SelectionChanged(object sender, SelectionChangedEventArgs e)
		{
			if (sender is not ComboBox comboBox || comboBox.SelectedItem is not ComboBoxItem selectedItem ||
				string.IsNullOrWhiteSpace(selectedItem.Tag?.ToString())) return;
			string selectedLanguageCode = selectedItem.Tag.ToString();

			if (selectedLanguageCode == _appSettings.Language)
			{
				return;
			}

			_appSettings.Language = selectedLanguageCode;
			ParseValuesIntoAppSettings();
			_appSettingsController.SaveSettings(_appSettings);
			MarkSettingsSaved();

			if (MessageBox.Show(Properties.Resources.Code_Main_MessageBox_Restart, Properties.Resources.Code_Main_MessageBox_Restart_Title, MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
			{
				AppRestart();
			}
		}

		private void InitializeAppearanceControls()
		{
			_appearanceControlsReady = false;
			chatNavigation_Button.Content = Properties.Resources.ResourceManager.GetString("Window_Main_Navigation_Chat");
			triggerNavigation_Button.Content = Properties.Resources.ResourceManager.GetString("Window_Main_Navigation_Triggers");
			integrationsNavigation_Button.Content = Properties.Resources.ResourceManager.GetString("Window_Main_Navigation_Integrations");
			appearanceHeading_TextBlock.Text = Properties.Resources.ResourceManager.GetString("Window_Main_Appearance_Heading");
			themeLabel_TextBlock.Text = Properties.Resources.ResourceManager.GetString("Window_Main_Appearance_Theme");
			accentLabel_TextBlock.Text = Properties.Resources.ResourceManager.GetString("Window_Main_Appearance_Accent");
			themeLight_Item.Content = Properties.Resources.ResourceManager.GetString("Window_Main_Appearance_Light");
			themeDark_Item.Content = Properties.Resources.ResourceManager.GetString("Window_Main_Appearance_Dark");
			themeSystem_Item.Content = Properties.Resources.ResourceManager.GetString("Window_Main_Appearance_System");

			SelectComboBoxItem(theme_ComboBox, _appSettings.Theme ?? "Light");
			SelectComboBoxItem(accent_ComboBox, _appSettings.AccentColor ?? "TwitchPurple");
			_appearanceControlsReady = true;
			UpdateNavigationState(-1);
		}

		private static string Text(string key) => Properties.Resources.ResourceManager.GetString(key) ?? key;

		private void InitializeP22Texts()
		{
			blocklistHeading_TextBlock.Text = Text("P22_Blocklist_Heading");
			blocklistDescription_TextBlock.Text = Text("P22_Blocklist_Description");
			blacklist_CheckBox.Content = Text("P22_Blocklist_Enable");
			blocklistAdd_Button.Content = Text("P22_Blocklist_Add");
			blocklistRemove_Button.Content = Text("P22_Blocklist_Remove");
			blocklistClear_Button.Content = Text("P22_Blocklist_Clear");
			blocklistSearch_TextBox.ToolTip = Text("P22_Blocklist_Search");
			blocklistSummaryHeading_TextBlock.Text = Text("P22_Blocklist_Heading");
			blocklistManage_Button.Content = Text("P25_Blocklist_Manage");
			blocklistBack_Button.Content = Text("P25_Back");
			blocklistHelpHeading_TextBlock.Text = Text("P22_Blocklist_Heading");
			blocklistHelpBody_TextBlock.Text = Text("P22_Blocklist_Help");
			streamElementsHelp_TabItem.Header = "StreamElements";
			streamElementsDescription_TextBlock.Text = Text("P22_StreamElements_Description");
			streamElementsEnabled_CheckBox.Content = Text("P22_StreamElements_Enable");
			streamElementsAutoConnect_CheckBox.Content = Text("P22_StreamElements_AutoConnect");
			streamElementsTokenType_Label.Text = Text("P22_StreamElements_TokenType");
			streamElementsToken_Label.Text = Text("P22_StreamElements_Token");
			streamElementsConnect_Button.Content = Text("P22_StreamElements_Connect");
			streamElementsDisconnect_Button.Content = Text("P22_StreamElements_Disconnect");
			streamElementsTestHeading_TextBlock.Text = Text("P22_StreamElements_TestHeading");
			streamElementsTest_Button.Content = Text("P22_StreamElements_Test");
			streamElementsHelpBody_TextBlock.Text = Text("P22_StreamElements_Help");
			consoleClear_Button.Content = Text("P23_Console_Clear");
			consoleOpenLog_Button.Content = Text("P23_Console_OpenLog");
			consoleAutoScroll_CheckBox.Content = Text("P23_Console_AutoScroll");
			consoleSearch_TextBox.ToolTip = Text("P25_Console_Search");
			consoleSearchHint_TextBlock.Text = Text("P25_Console_Search");
			consoleSupportLog_Button.Content = Text("P25_Console_SupportLog");
			consoleCopySelected_MenuItem.Header = Text("P25_Console_CopySelected");
			consoleCopyVisible_MenuItem.Header = Text("P25_Console_CopyVisible");
			SetComboBoxItemContent(consoleLevelFilter_ComboBox, "All", Text("P25_Console_All"));
			SetComboBoxItemContent(consoleLevelFilter_ComboBox, "INFO", Text("P25_Console_Info"));
			SetComboBoxItemContent(consoleLevelFilter_ComboBox, "WARN", Text("P25_Console_Warnings"));
			SetComboBoxItemContent(consoleLevelFilter_ComboBox, "ERROR", Text("P25_Console_Errors"));
			SetComboBoxItemContent(consoleLevelFilter_ComboBox, "DEBUG", Text("P25_Console_Debug"));
			p24TriggerHelpHeading_TextBlock.Text = Text("P24_Trigger_Search");
			p24TriggerHelpBody_TextBlock.Text = Text("P24_Trigger_Help");
			consoleSearch_TextBox.SetResourceReference(FocusVisualStyleProperty, "NtlFocusVisualStyle");
			ConnectChat_Button.ToolTip = Text("P28_Disabled_ConnectChat");
			nanoTestConnection_Button.ToolTip = Text("P28_Disabled_NanoTest");
			nanoCmd_Button.ToolTip = Text("P28_Disabled_EditTrigger");
		}

		private void RefreshBlocklist()
		{
			if (blocklist_ListBox == null) return;
			string filter = blocklistSearch_TextBox?.Text?.Trim() ?? string.Empty;
			blocklist_ListBox.ItemsSource = (_appSettings.Blacklist ?? new List<string>())
				.Where(name => string.IsNullOrEmpty(filter) || name.Contains(filter, StringComparison.OrdinalIgnoreCase))
				.OrderBy(name => name, StringComparer.OrdinalIgnoreCase)
				.ToList();
			blocklistRemove_Button.IsEnabled = blocklist_ListBox.SelectedItem != null;
			blocklistClear_Button.IsEnabled = _appSettings.Blacklist?.Count > 0;
			RefreshBlocklistSummary();
		}

		private void RefreshBlocklistSummary()
		{
			if (blocklistSummaryStatus_TextBlock == null) return;
			blocklistSummaryStatus_TextBlock.Text = string.Format(
				_appSettings.BlacklistEnabled ? Text("P25_Blocklist_StatusActive") : Text("P25_Blocklist_StatusInactive"),
				_appSettings.Blacklist?.Count ?? 0);
		}

		private void BlocklistManage_Button_Click(object sender, RoutedEventArgs e) => ShowEmbeddedBlocklist();

		private void ShowEmbeddedBlocklist()
		{
			RefreshBlocklist();
			chatconsole_TabControl.Visibility = Visibility.Collapsed;
			settings_TabControl.Visibility = Visibility.Collapsed;
			integrationTabs_Panel.Visibility = Visibility.Collapsed;
			triggerManager_Host.Visibility = Visibility.Collapsed;
			appInfo_Host.Visibility = Visibility.Collapsed;
			management_Host.Visibility = Visibility.Collapsed;
			helpPanel.Visibility = Visibility.Collapsed;
			Save_Button.Visibility = Visibility.Collapsed;
			blocklistPanel.Visibility = Visibility.Visible;
			_currentPage = 0;
			UpdateNavigationState(0);
			Dispatcher.BeginInvoke(new Action(() => blocklistInput_TextBox.Focus()));
		}

		private void BlocklistBack_Button_Click(object sender, RoutedEventArgs e) => ShowMainPage(0);

		private void BlocklistAdd_Button_Click(object sender, RoutedEventArgs e)
		{
			string username = (blocklistInput_TextBox.Text ?? string.Empty).Trim().TrimStart('@').ToLowerInvariant();
			if (string.IsNullOrWhiteSpace(username))
			{
				MessageBox.Show(Properties.Resources.General_MessageBox_EnterUsername, Properties.Resources.General_MessageBox_Error_Title);
				return;
			}
			_appSettings.Blacklist ??= new List<string>();
			if (_appSettings.Blacklist.Any(item => item.Equals(username, StringComparison.OrdinalIgnoreCase)))
			{
				MessageBox.Show(Properties.Resources.General_MessageBox_UsernameExists, Properties.Resources.General_MessageBox_Error_Title);
				return;
			}
			_appSettings.Blacklist.Add(username);
			blocklistInput_TextBox.Clear();
			_appSettingsController.SaveSettings(_appSettings);
			_logger.Info(string.Format(Properties.Resources.General_Blacklist_MessageBox_AddedUserX, username));
			RefreshBlocklist();
			ShowToast(string.Format(Text("P25_Toast_BlocklistAdded"), username));
		}

		private void BlocklistRemove_Button_Click(object sender, RoutedEventArgs e)
		{
			if (blocklist_ListBox.SelectedItem is not string username) return;
			_appSettings.Blacklist.RemoveAll(item => item.Equals(username, StringComparison.OrdinalIgnoreCase));
			_appSettingsController.SaveSettings(_appSettings);
			_logger.Info(string.Format(Properties.Resources.General_Blacklist_MessageBox_RemovedUserX, username));
			RefreshBlocklist();
			ShowToast(Text("P25_Toast_BlocklistRemoved"));
		}

		private void BlocklistClear_Button_Click(object sender, RoutedEventArgs e)
		{
			if (_appSettings.Blacklist == null || _appSettings.Blacklist.Count == 0) return;
			if (MessageBox.Show(Text("P22_Blocklist_ConfirmClear"), Text("P22_Blocklist_Heading"), MessageBoxButton.YesNo, MessageBoxImage.Warning) != MessageBoxResult.Yes) return;
			_appSettings.Blacklist.Clear();
			_appSettingsController.SaveSettings(_appSettings);
			RefreshBlocklist();
			ShowToast(Text("P25_Toast_BlocklistCleared"));
		}

		private void BlocklistInput_TextBox_KeyDown(object sender, KeyEventArgs e)
		{
			if (e.Key == Key.Enter) BlocklistAdd_Button_Click(sender, e);
		}

		private void BlocklistSearch_TextBox_TextChanged(object sender, TextChangedEventArgs e) => RefreshBlocklist();
		private void Blocklist_ListBox_SelectionChanged(object sender, SelectionChangedEventArgs e) => blocklistRemove_Button.IsEnabled = blocklist_ListBox.SelectedItem != null;
		private void BlocklistHelp_Button_Click(object sender, RoutedEventArgs e) => ShowHelp(HelpTopic.Twitch, ShowEmbeddedBlocklist);
		private void StreamElementsHelp_Button_Click(object sender, RoutedEventArgs e) => ShowHelp(HelpTopic.StreamElements);

		private void ReadStreamElementsControls()
		{
			_appSettings.StreamElements.Enabled = streamElementsEnabled_CheckBox.IsChecked == true;
			_appSettings.StreamElements.AutoConnect = streamElementsAutoConnect_CheckBox.IsChecked == true;
			_appSettings.StreamElements.Token = streamElementsToken_PasswordBox.Password?.Trim() ?? string.Empty;
			_appSettings.StreamElements.TokenType = (streamElementsTokenType_ComboBox.SelectedItem as ComboBoxItem)?.Tag?.ToString() ?? "jwt";
		}

		private async void StreamElementsConnect_Button_Click(object sender, RoutedEventArgs e)
		{
			ReadStreamElementsControls();
			_appSettingsController.SaveSettings(_appSettings);
			streamElementsConnect_Button.IsEnabled = false;
			bool connected = await _streamElementsController.ConnectAsync();
			if (!connected) streamElementsConnect_Button.IsEnabled = true;
		}

		private async void StreamElementsDisconnect_Button_Click(object sender, RoutedEventArgs e)
		{
			await _streamElementsController.DisconnectAsync();
		}

		private void StreamElementsController_ConnectionStateChanged(bool connected, string detail)
		{
			Dispatcher.BeginInvoke(new Action(() =>
			{
				UpdateStreamElementsStatus(connected, detail);
				if (connected) _appSettingsController.SaveSettings(_appSettings);
			}));
		}

		private void UpdateStreamElementsStatus(bool connected, string detail)
		{
			streamElementsConnect_Button.IsEnabled = !connected;
			streamElementsDisconnect_Button.IsEnabled = connected;
			if (connected)
			{
				string suffix = string.IsNullOrWhiteSpace(detail) ? string.Empty : $" ({detail})";
				streamElementsStatus_TextBlock.Text = string.Format(Text("P22_StreamElements_StatusConnected"), suffix);
				streamElementsStatus_TextBlock.SetResourceReference(ForegroundProperty, "NtlSuccessBrush");
			}
			else if (!string.IsNullOrWhiteSpace(detail) && detail != "disconnected" && detail != "not-configured")
			{
				streamElementsStatus_TextBlock.Text = string.Format(Text("P22_StreamElements_StatusError"), detail);
				streamElementsStatus_TextBlock.Foreground = System.Windows.Media.Brushes.IndianRed;
			}
			else
			{
				streamElementsStatus_TextBlock.Text = Text("P22_StreamElements_StatusDisconnected");
				streamElementsStatus_TextBlock.SetResourceReference(ForegroundProperty, "NtlMutedTextBrush");
			}
		}

		private void StreamElementsTest_Button_Click(object sender, RoutedEventArgs e)
		{
			if (!double.TryParse(streamElementsTestAmount_TextBox.Text, NumberStyles.Float, CultureInfo.CurrentCulture, out double amount) || amount < 0)
			{
				MessageBox.Show(Text("P22_StreamElements_InvalidAmount"), Properties.Resources.General_MessageBox_Error_Title);
				return;
			}
			_streamElementsController.SimulateDonation(amount, streamElementsTestUser_TextBox.Text);
			ShowToast(Text("P25_Toast_TestTriggered"));
		}

		private static void SelectComboBoxItem(ComboBox comboBox, string tag)
		{
			foreach (ComboBoxItem item in comboBox.Items)
			{
				if (string.Equals(item.Tag?.ToString(), tag, StringComparison.OrdinalIgnoreCase))
				{
					comboBox.SelectedItem = item;
					return;
				}
			}
			comboBox.SelectedIndex = 0;
		}

		private static void SetComboBoxItemContent(ComboBox comboBox, string tag, string content)
		{
			foreach (ComboBoxItem item in comboBox.Items)
				if (string.Equals(item.Tag?.ToString(), tag, StringComparison.OrdinalIgnoreCase)) item.Content = content;
		}

		private void Theme_ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
		{
			if (!_appearanceControlsReady || theme_ComboBox.SelectedItem is not ComboBoxItem item) return;
			_appSettings.Theme = item.Tag.ToString();
			ThemeManager.Apply(_appSettings.Theme, _appSettings.AccentColor);
		}

		private void Accent_ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
		{
			if (!_appearanceControlsReady || accent_ComboBox.SelectedItem is not ComboBoxItem item) return;
			_appSettings.AccentColor = item.Tag.ToString();
			ThemeManager.Apply(_appSettings.Theme, _appSettings.AccentColor);
		}

		private void Navigation_Button_Click(object sender, RoutedEventArgs e)
		{
			if (sender is not Button button || !int.TryParse(button.Tag?.ToString(), out int page)) return;
			ShowMainPage(page);
		}

		private void ShowMainPage(int page)
		{
			bool showChat = page < 0;
			bool showIntegrations = (page >= 3 && page <= 5) || page == 9;
			triggerManager_Host.Visibility = Visibility.Collapsed;
			appInfo_Host.Visibility = Visibility.Collapsed;
			management_Host.Visibility = Visibility.Collapsed;
			helpPanel.Visibility = Visibility.Collapsed;
			blocklistPanel.Visibility = Visibility.Collapsed;
			Save_Button.Visibility = Visibility.Visible;
			chatconsole_TabControl.Visibility = showChat ? Visibility.Visible : Visibility.Collapsed;
			settings_TabControl.Visibility = showChat ? Visibility.Collapsed : Visibility.Visible;
			integrationTabs_Panel.Visibility = showIntegrations ? Visibility.Visible : Visibility.Collapsed;
			settings_TabControl.Margin = showIntegrations
				? new Thickness(20, 68, 20, 76)
				: new Thickness(20, 20, 20, 76);
			if (!showChat) settings_TabControl.SelectedIndex = page == 9 ? 6 : page;
			_currentPage = page;
			UpdateNavigationState(page);
		}

		private void UpdateNavigationState(int page)
		{
			foreach (Button navigationButton in navigationButtons_Panel.Children.OfType<Button>())
			{
				if (!int.TryParse(navigationButton.Tag?.ToString(), out int targetPage)) continue;
				bool active = targetPage == page || (targetPage == 3 && ((page >= 3 && page <= 5) || page == 9));
				if (active)
				{
					navigationButton.SetResourceReference(BackgroundProperty, "NtlAccentSurfaceBrush");
					navigationButton.FontWeight = FontWeights.SemiBold;
				}
				else
				{
					navigationButton.Background = System.Windows.Media.Brushes.Transparent;
					navigationButton.ClearValue(FontWeightProperty);
				}
			}

			foreach (Button integrationButton in integrationTabs_Panel.Children.OfType<Button>())
			{
				bool active = int.TryParse(integrationButton.Tag?.ToString(), out int targetPage) && targetPage == page;
				if (active)
				{
					integrationButton.SetResourceReference(BackgroundProperty, "NtlAccentSurfaceBrush");
					integrationButton.FontWeight = FontWeights.SemiBold;
				}
				else
				{
					integrationButton.ClearValue(BackgroundProperty);
					integrationButton.ClearValue(FontWeightProperty);
				}
			}

			if (page == 7)
			{
				infoNavigation_Button.SetResourceReference(BackgroundProperty, "NtlAccentSurfaceBrush");
				infoNavigation_Button.FontWeight = FontWeights.SemiBold;
			}
			else
			{
				infoNavigation_Button.Background = System.Windows.Media.Brushes.Transparent;
				infoNavigation_Button.ClearValue(FontWeightProperty);
			}

			if (page == 8)
			{
				helpNavigation_Button.SetResourceReference(BackgroundProperty, "NtlAccentSurfaceBrush");
				helpNavigation_Button.FontWeight = FontWeights.SemiBold;
			}
			else
			{
				helpNavigation_Button.Background = System.Windows.Media.Brushes.Transparent;
				helpNavigation_Button.ClearValue(FontWeightProperty);
			}
		}

		private void HelpNavigation_Button_Click(object sender, RoutedEventArgs e)
		{
			ShowHelp(HelpTopic.General, null, true);
		}

		public void ShowHelp(HelpTopic topic, Action returnAction = null, bool returnToSelectedTopic = false)
		{
			if (_currentPage != 8) _helpReturnPage = _currentPage;
			_helpReturnAction = returnAction;
			_helpReturnFollowsSelectedTopic = returnToSelectedTopic;
			chatconsole_TabControl.Visibility = Visibility.Collapsed;
			settings_TabControl.Visibility = Visibility.Collapsed;
			integrationTabs_Panel.Visibility = Visibility.Collapsed;
			triggerManager_Host.Visibility = Visibility.Collapsed;
			appInfo_Host.Visibility = Visibility.Collapsed;
			management_Host.Visibility = Visibility.Collapsed;
			blocklistPanel.Visibility = Visibility.Collapsed;
			Save_Button.Visibility = Visibility.Collapsed;
			helpPanel.Visibility = Visibility.Visible;
			help_TabControl.SelectedIndex = (int)topic;
			if (_helpReturnFollowsSelectedTopic) _helpReturnPage = GetPageForHelpTopic(topic);
			_currentPage = 8;
			UpdateNavigationState(8);
			Show();
			Activate();
		}

		private void Help_TabControl_SelectionChanged(object sender, SelectionChangedEventArgs e)
		{
			if (!_helpReturnFollowsSelectedTopic || help_TabControl.SelectedIndex < 0) return;
			_helpReturnPage = GetPageForHelpTopic((HelpTopic)help_TabControl.SelectedIndex);
		}

		private static int GetPageForHelpTopic(HelpTopic topic)
		{
			switch (topic)
			{
				case HelpTopic.Nano:
				case HelpTopic.Devices:
					return 1;
				case HelpTopic.Trigger:
					return 6;
				case HelpTopic.Twitch:
					return 0;
				case HelpTopic.Integrations:
					return 3;
				case HelpTopic.General:
				case HelpTopic.ChatResponses:
				default:
					return 2;
			}
		}

		private void HelpBack_Button_Click(object sender, RoutedEventArgs e)
		{
			int returnPage = _helpReturnPage;
			Action returnAction = _helpReturnAction;
			_helpReturnAction = null;
			_helpReturnFollowsSelectedTopic = false;
			if (returnPage == 6) ShowEmbeddedTriggerManager();
			else if (returnPage == 7) ShowEmbeddedAppInfo();
			else ShowMainPage(returnPage == 8 ? -1 : returnPage);
			returnAction?.Invoke();
		}

		private async void SetBaseColor_Button_Click(object sender, RoutedEventArgs e)
		{
			if (ColorPicker.SelectedColor == null)
			{
				MessageBox.Show(Properties.Resources.Window_TriggerDetail_ColorPicker_Error,
					Properties.Resources.General_MessageBox_Error_Title);
				return;
			}
			foreach (var device in _appSettings.NanoSettings.NanoLeafDevices)
			{
				var pickerColor = ColorPicker.SelectedColor.Value;
				var color = new RgbColor(pickerColor.R, pickerColor.G, pickerColor.B, 255);
				await _nanoController.SetColor(device, color);
			}
		}

		private void ConnectTwitchAccount_Button_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				var twitchLinkWindow = new TwitchLinkWindow(_appSettings, _twitchController, _appSettingsController);
				WindowPlacementService.PrepareOwnedWindow(twitchLinkWindow, this);
				twitchLinkWindow.ShowDialog();
			}
			catch (Exception exception)
			{
				_logger.Error("Could not open Twitch account connection.", exception);
				MessageBox.Show(
					Properties.Resources.ResourceManager.GetString("Code_Main_MessageBox_TwitchConnection_Error") +
					$"\n\n{exception.Message}\n\n{Properties.Resources.ResourceManager.GetString("General_LogFile_Label")}:\n{Constants.LOG_PATH}",
					Properties.Resources.General_MessageBox_Error_Title,
					MessageBoxButton.OK,
					MessageBoxImage.Error);
			}
		}

		private void DisconnectTwitchAccount_Button_Click(object sender, RoutedEventArgs e)
		{
			TwitchLinkAvatar_Image.Source = new BitmapImage(new Uri("/NanoTwitchLeafs;component/Assets/nanotwitchleafs_error_logo.png", UriKind.Relative));
			_appSettings.BroadcasterAvatarUrl = null;
			_appSettings.BotAvatarUrl = null;
			_appSettings.BotAuthObject = null;
			_appSettings.BroadcasterAuthObject = null;
			_appSettings.BroadcasterAvatarUrl = null;
			_appSettings.BotAvatarUrl = null;
			_appSettings.ChannelName = null;
			if (_twitchController.Client != null && _twitchController.Client.IsConnected)
			{
				DisconnectFromChat();
			}
			_appSettingsController.SaveSettings(_appSettings);
			DisconnectTwitchAccount_Button.IsEnabled = false;
			ConnectTwitchAccount_Button.IsEnabled = true;
			ConnectChat_Button.IsEnabled = false;
			TwitchLink_Label.Content = Properties.Resources.Window_Main_Tabs_TwitchLogin_AccountLabel_Text;
		}

		private void ConnectChat_Button_Click(object sender, RoutedEventArgs e)
		{
			ConnectToChat();
		}

		private void DisconnectChat_Button_Click(object sender, RoutedEventArgs e)
		{
			DisconnectFromChat();
		}
		private void Main_Window_Closed(object sender, EventArgs e)
		{
			_toastTimer.Stop();
			_tbi?.Dispose();
		}

		private void StreamlabsConnectButton_Click(object sender, RoutedEventArgs e)
		{
			_logger.Info("Connect to Streamlabs Socket");
			_streamlabsController.ConnectSocket();

			StreamlabsConnectButton.IsEnabled = false;
			StreamlabsDisconnectButton.IsEnabled = true;
		}

		private void StreamlabsDisconnectButton_Click(object sender, RoutedEventArgs e)
		{
			if (_streamlabsController._IsSocketConnected)
			{
				_logger.Info("Disconnect from Streamlabs Socket");
				_streamlabsController.DisconnectSocket();
			}
			StreamlabsConnectButton.IsEnabled = true;
			StreamlabsDisconnectButton.IsEnabled = false;
		}

		private void HypeRateConnect_Button_Click(object sender, RoutedEventArgs e)
		{
			_appSettings.HypeRateId = hypeRateId_Textbox.Text;
			if (_appSettings.HypeRateId == "HypeRateId" || string.IsNullOrWhiteSpace(_appSettings.HypeRateId))
			{
				MessageBox.Show(Properties.Resources.Window_Main_Tabs_HypeRate_MessageBox_EnterID_Text, Properties.Resources.General_MessageBox_Error_Title,
					MessageBoxButton.OK, MessageBoxImage.Error);
				_logger.Error("Please enter your HypeRate Id");
				return;
			}
			_hypeRatecontroller.StartListener();
		}

		private void HypeRateDisconnect_Button_Click(object sender, RoutedEventArgs e)
		{
			_hypeRatecontroller.Disconnect();
		}

		private void _hypeRatecontroller_OnHypeRateDisconnected()
		{
			Application.Current.Dispatcher.Invoke(() =>
			{
				HypeRateConnect_Button.IsEnabled = true;
				HypeRateDisconnect_Button.IsEnabled = false;
			});
		}

		private void _hypeRatecontroller_OnHypeRateConnected()
		{
			Application.Current.Dispatcher.Invoke(() =>
			{
				HypeRateConnect_Button.IsEnabled = false;
				HypeRateDisconnect_Button.IsEnabled = true;
			});
		}

		private void _hypeRatecontroller_OnHeartRateRecieved(int heartRate)
		{
			Application.Current.Dispatcher.Invoke(() =>
			{
				hypeRate_Label.Content = heartRate;
			});
		}

		private async void StreamlabsLink_Button_Click(object sender, RoutedEventArgs e)
		{
			if (await _streamlabsController.LinkAccount())
			{
				Streamlabs_Image.Source = TwitchLinkAvatar_Image.Source;
				StreamlabsLink_Button.IsEnabled = false;
				StreamlabsUnlink_Button.IsEnabled = true;
				StreamlabsConnectButton.IsEnabled = true;
				StreamlabsInfo_TextBlock.Text = $"{Properties.Resources.Windows_Main_Tabs_Streamlabs_Linktext_Textblock2} {_appSettings.ChannelName}.";
			}
			else
			{
				_logger.Error("Could not connect Streamlabs Account!");
			}
		}

		private void StreamlabsUnlink_Button_Click(object sender, RoutedEventArgs e)
		{
			_appSettings.StreamlabsInformation = new StreamlabsInformation();
			StreamlabsInfo_TextBlock.Text = Properties.Resources.Windows_Main_Tabs_Streamlabs_Linktext_Textblock1;
			StreamlabsLink_Button.IsEnabled = true;
			StreamlabsUnlink_Button.IsEnabled = false;
			StreamlabsConnectButton.IsEnabled = false;
			Streamlabs_Image.Source = new BitmapImage(new Uri("/NanoTwitchLeafs;component/Assets/nanotwitchleafs_error_logo.png", UriKind.Relative));
		}

		private void HypeRateDiscord_Label_MouseDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
		{
			//https://discord.gg/dqutnTAj6j
			Process.Start("https://discord.gg/dqutnTAj6j");
		}

		private void HypeRateWebsite_Label_MouseDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
		{
			//https://hyperate.io
			Process.Start("https://hyperate.io");
		}

		private void Open_Dir_Button_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				Directory.CreateDirectory(Constants.PROGRAMFILESFOLDER_PATH);
				Process.Start(new ProcessStartInfo
				{
					FileName = "explorer.exe",
					Arguments = $"\"{Constants.PROGRAMFILESFOLDER_PATH}\"",
					UseShellExecute = true
				});
			}
			catch (Exception ex)
			{
				_logger.Error("Could not open the program data directory.", ex);
				MessageBox.Show(Properties.Resources.General_MessageBox_GeneralError_Text,
					Properties.Resources.General_MessageBox_Error_Title, MessageBoxButton.OK, MessageBoxImage.Error);
			}
		}


		private void Save_Button_Click(object sender, RoutedEventArgs e)
		{
			// ParseSettings
			ParseValuesIntoAppSettings();

			// Save all
			_appSettingsController.SaveSettings(_appSettings);
			MarkSettingsSaved();
			ShowToast(Text("P25_Toast_SettingsSaved"));
		}

		private void ParseValuesIntoAppSettings()
		{
			// Bot Settings
			_appSettings.WhisperMode = whisperMode_Checkbox.IsChecked == true;
			_appSettings.CommandPrefix = commandPrefix_TextBox.Text;
			_appSettings.ChatResponse = response_CheckBox.IsChecked == true;

			// Nano Settings
			_appSettings.NanoSettings.TriggerEnabled = nanoCmd_Checkbox.IsChecked == true;
			_appSettings.NanoSettings.CooldownEnabled = nanoCooldown_Checkbox.IsChecked == true;
			_appSettings.NanoSettings.Cooldown = int.TryParse(nanoCooldown_TextBox.Text, out int cooldown) && cooldown >= 0 ? cooldown : 0;
			_appSettings.NanoSettings.ChangeBackOnCommand = commandRestore_CheckBox.IsChecked == true;
			_appSettings.NanoSettings.ChangeBackOnKeyword = keywordRestore_Checkbox.IsChecked == true;

			// App Settings
			_appSettings.AutoIpRefresh = autoIPRefresh_Checkbox.IsChecked == true;
			_appSettings.DebugEnabled = debugCmd_Checkbox.IsChecked == true;
			_appSettings.AutoConnect = autoConnect_Checkbox.IsChecked == true;
			_appSettings.BlacklistEnabled = blacklist_CheckBox.IsChecked == true;
			if (updateSource_ComboBox.SelectedItem is ComboBoxItem updateSourceItem &&
				!string.IsNullOrWhiteSpace(updateSourceItem.Tag?.ToString()))
			{
				_appSettings.UpdateSource = updateSourceItem.Tag.ToString();
			}


			// Hype Rate
			_appSettings.HypeRateId = hypeRateId_Textbox.Text;

			// Streamlabs
			_appSettings.StreamlabsClientId = StreamlabsClientId_Textbox.Text;
			_appSettings.StreamlabsClientSecret = StreamlabsClientSecret_Textbox.Password;
			_appSettings.HypeRateApiKey = HypeRateApiKey_Textbox.Password;
			ReadStreamElementsControls();
		}

		private void SendMessage_Button_Click(object sender, RoutedEventArgs e)
		{
			string username = _appSettings.BotName;
			string message = sendMessage_TextBox.Text;
			_twitchController.SendMessageToChat(message);
			_triggerLogicController.HandleMessage(new ChatMessage(username, true, true, true, message, new Color()));
			sendMessage_TextBox.Text = "";

			string formattedMessage = $"{DateTime.Now.ToLongTimeString()}: {username} - {message}";

			_logger.Info(formattedMessage);

			twitchChat_ListBox.Dispatcher.Invoke(() =>
			{
				_twitchChat.Add(formattedMessage);
				twitchChat_ListBox.Items.Refresh();
				UpdateScrollBar(twitchChat_ListBox);
			});
		}

		private void SendMessage_TextBox_TouchEnter(object sender, System.Windows.Input.TouchEventArgs e)
		{
			SendMessage_Button_Click(sender, e);
		}

		private void NanoCmd_Button_Click(object sender, RoutedEventArgs e)
		{
			ShowEmbeddedTriggerManager();
		}

		private void TriggerNavigation_Button_Click(object sender, RoutedEventArgs e)
		{
			ShowEmbeddedTriggerManager();
		}

		private void ShowEmbeddedTriggerManager()
		{
			try
			{
				if (_currentPage != 6) _embeddedReturnPage = _currentPage;
				if (_embeddedTriggerManager == null)
				{
					_embeddedTriggerManager = new TriggerWindow(_commandRepository, _nanoController, _appSettings, _appSettingsController, _streamlabsController, _hypeRatecontroller, _triggerLogicController, _twitchEventSubController);
					UIElement triggerContent = _embeddedTriggerManager.Content as UIElement;
					_embeddedTriggerManager.Content = null;
					triggerManager_Host.Content = triggerContent;
				}
				else _embeddedTriggerManager.RefreshTriggerList();

				chatconsole_TabControl.Visibility = Visibility.Collapsed;
				settings_TabControl.Visibility = Visibility.Collapsed;
				appInfo_Host.Visibility = Visibility.Collapsed;
				management_Host.Visibility = Visibility.Collapsed;
				blocklistPanel.Visibility = Visibility.Collapsed;
				helpPanel.Visibility = Visibility.Collapsed;
				integrationTabs_Panel.Visibility = Visibility.Collapsed;
				Save_Button.Visibility = Visibility.Collapsed;
				triggerManager_Host.Visibility = Visibility.Visible;
				_currentPage = 6;
				UpdateNavigationState(6);
			}
			catch (Exception ex)
			{
				_logger.Error("Trigger manager could not be opened.", ex);
				MessageBox.Show(Properties.Resources.ResourceManager.GetString("Window_Main_TriggerManager_Open_Error"), Properties.Resources.General_MessageBox_Error_Title);
			}
		}

		private void NanoCmd_Checkbox_Click(object sender, RoutedEventArgs e)
		{
#if !DEBUG
            if (_appSettings.DebugEnabled == false && _appSettings.NanoSettings.NanoLeafDevices.Count < 1)
            {
                MessageBox.Show(Properties.Resources.Code_Main_MessageBox_PairDevice, Properties.Resources.General_MessageBox_Error_Title);
                _logger.Error("Can't Enable Commands without Pairing and Test Connection first!");
                nanoCmd_Checkbox.IsChecked = false;
                nanoCmd_Button.IsEnabled = false;
                return;
            }
#endif

			if (nanoCmd_Checkbox.IsChecked == true)
			{
				nanoCmd_Button.IsEnabled = true;
				_appSettings.NanoSettings.TriggerEnabled = true;
			}
			else if (nanoCmd_Checkbox.IsChecked == false)
			{
				nanoCmd_Button.IsEnabled = false;
				_appSettings.NanoSettings.TriggerEnabled = false;
			}
		}

		private void nanoPairing_Button_Click(object sender, RoutedEventArgs e)
		{
			PairingWindow pairingWindow = new PairingWindow(_appSettings, _nanoController);
			WindowPlacementService.PrepareOwnedWindow(pairingWindow, this);

			if (!CheckForDuplicateWindow(pairingWindow))
			{
				pairingWindow.Show();
			}
		}

		private async void NanoTestConnection_Button_Click(object sender, RoutedEventArgs e)
		{
			await TestNanoConnection();
		}

		private void AppInfo_Button_Click(object sender, RoutedEventArgs e)
		{
			ShowEmbeddedAppInfo();
		}

		private void ShowEmbeddedAppInfo()
		{
			try
			{
				if (_currentPage != 7) _embeddedReturnPage = _currentPage;
				if (_embeddedAppInfo == null)
				{
					_embeddedAppInfo = new AppInfoWindow(_appSettings, _appSettingsController);
					UIElement infoContent = _embeddedAppInfo.Content as UIElement;
					_embeddedAppInfo.Content = null;
					appInfo_Host.Content = infoContent;
				}
				chatconsole_TabControl.Visibility = Visibility.Collapsed;
				settings_TabControl.Visibility = Visibility.Collapsed;
				integrationTabs_Panel.Visibility = Visibility.Collapsed;
				triggerManager_Host.Visibility = Visibility.Collapsed;
				management_Host.Visibility = Visibility.Collapsed;
				blocklistPanel.Visibility = Visibility.Collapsed;
				helpPanel.Visibility = Visibility.Collapsed;
				Save_Button.Visibility = Visibility.Collapsed;
				appInfo_Host.Visibility = Visibility.Visible;
				_currentPage = 7;
				UpdateNavigationState(7);
			}
			catch (Exception ex)
			{
				_logger.Error("Program information could not be opened.", ex);
				MessageBox.Show(Properties.Resources.General_MessageBox_GeneralError_Text,
					Properties.Resources.General_MessageBox_Error_Title, MessageBoxButton.OK, MessageBoxImage.Error);
			}
		}

		private void SendMessage_TextBox_KeyDown(object sender, System.Windows.Input.KeyEventArgs e)
		{
			if (e.Key == System.Windows.Input.Key.Enter)
			{
				SendMessage_Button_Click(sender, e);
			}
		}

		private void WhisperMode_Checkbox_Click(object sender, RoutedEventArgs e)
		{
			if (whisperMode_Checkbox.IsChecked == true)
			{
				_appSettings.WhisperMode = true;
				_logger.Info("Whisper Mode enabled!");
			}
			else if (whisperMode_Checkbox.IsChecked == false)
			{
				_appSettings.WhisperMode = false;
				_logger.Info("Whisper Mode disabled!");
			}
		}

		private void DebugCmd_Checkbox_Click(object sender, RoutedEventArgs e)
		{
			if (debugCmd_Checkbox.IsChecked == true)
			{
				_appSettings.DebugEnabled = true;
				SetLogLevel(Level.Debug);
				_logger.Info("Debug Mode enabled!");
			}
			else if (debugCmd_Checkbox.IsChecked == false)
			{
				_appSettings.DebugEnabled = false;
				SetLogLevel(Level.Info);
				_logger.Info("Debug Mode disabled!");
			}
		}

		private void UpdateScrollBar(ListBox listBox)
		{
			if (listBox != null && listBox.Items.Count > 0)
			{
				listBox.SelectedIndex = listBox.Items.Count - 1;
				listBox.UpdateLayout();
				listBox.ScrollIntoView(listBox.Items[listBox.Items.Count - 1]);
			}
		}

		private void ConsoleClear_Button_Click(object sender, RoutedEventArgs e)
		{
			Console.Clear();
			_consoleView?.Refresh();
			UpdateConsoleResultCount();
			ShowToast(Text("P25_Toast_ConsoleCleared"));
		}

		private bool ConsoleEntryMatchesFilter(object value)
		{
			if (value is not ConsoleLogEntry entry) return false;
			string search = consoleSearch_TextBox?.Text?.Trim() ?? string.Empty;
			string level = (consoleLevelFilter_ComboBox?.SelectedItem as ComboBoxItem)?.Tag?.ToString() ?? "All";
			return (level == "All" || entry.Level == level) &&
				(string.IsNullOrWhiteSpace(search) || entry.Message?.Contains(search, StringComparison.OrdinalIgnoreCase) == true);
		}

		private void ConsoleFilter_Changed(object sender, RoutedEventArgs e)
		{
			if (consoleSearchHint_TextBlock != null)
				consoleSearchHint_TextBlock.Visibility = string.IsNullOrEmpty(consoleSearch_TextBox?.Text) ? Visibility.Visible : Visibility.Collapsed;
			_consoleView?.Refresh();
			UpdateConsoleResultCount();
			if (_consoleAutoScroll) UpdateScrollBar(console_ListBox);
		}

		private void UpdateConsoleResultCount()
		{
			if (consoleResultCount_TextBlock == null) return;
			int visible = _consoleView?.Cast<object>().Count() ?? Console.Count;
			consoleResultCount_TextBlock.Text = string.Format(Text("P25_Console_Count"), visible, Console.Count);
		}

		private void ConsoleCopySelected_MenuItem_Click(object sender, RoutedEventArgs e)
		{
			CopyConsoleEntries(console_ListBox.SelectedItems.Cast<ConsoleLogEntry>());
		}

		private void ConsoleCopyVisible_MenuItem_Click(object sender, RoutedEventArgs e)
		{
			CopyConsoleEntries((_consoleView?.Cast<ConsoleLogEntry>()) ?? Enumerable.Empty<ConsoleLogEntry>());
		}

		private void CopyConsoleEntries(IEnumerable<ConsoleLogEntry> entries)
		{
			string text = string.Join(Environment.NewLine, entries.Select(entry => entry.Message));
			if (string.IsNullOrWhiteSpace(text)) return;
			try { Clipboard.SetText(text); ShowToast(Text("P25_Toast_Copied")); }
			catch (Exception ex) { _logger.Warn("Could not copy console entries.", ex); }
		}

		private void ConsoleOpenLog_Button_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				Directory.CreateDirectory(Path.GetDirectoryName(Constants.LOG_PATH));
				if (!File.Exists(Constants.LOG_PATH))
					File.WriteAllText(Constants.LOG_PATH, string.Empty);
				Process.Start(new ProcessStartInfo
				{
					FileName = Constants.LOG_PATH,
					UseShellExecute = true
				});
			}
			catch (Exception ex)
			{
				_logger.Error("Could not open the log file.", ex);
				MessageBox.Show(Properties.Resources.General_MessageBox_GeneralError_Text,
					Properties.Resources.General_MessageBox_Error_Title, MessageBoxButton.OK, MessageBoxImage.Error);
			}
		}

		private void ConsoleSupportLog_Button_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				string supportDirectory = Path.Combine(Constants.PROGRAMFILESFOLDER_PATH, "Support");
				Directory.CreateDirectory(supportDirectory);
				string destination = Path.Combine(supportDirectory, $"NanoTwitchLeafs-support-{DateTime.Now:yyyyMMdd-HHmmss}.log");
				string source = File.Exists(Constants.LOG_PATH) ? File.ReadAllText(Constants.LOG_PATH) : string.Empty;
				string header = $"NanoTwitchLeafs {VersionBadgeText}{Environment.NewLine}Created: {DateTimeOffset.Now:O}{Environment.NewLine}{Environment.NewLine}";
				File.WriteAllText(destination, header + SanitizeSupportLog(source), Encoding.UTF8);
				Process.Start(new ProcessStartInfo { FileName = "explorer.exe", Arguments = $"/select,\"{destination}\"", UseShellExecute = true });
				ShowToast(Text("P25_Toast_SupportCreated"));
			}
			catch (Exception ex)
			{
				_logger.Error("Could not create the sanitized support log.", ex);
				MessageBox.Show(Properties.Resources.General_MessageBox_GeneralError_Text,
					Properties.Resources.General_MessageBox_Error_Title, MessageBoxButton.OK, MessageBoxImage.Error);
			}
		}

		private string SanitizeSupportLog(string content)
		{
			string sanitized = content ?? string.Empty;
			var secrets = new[]
			{
				_appSettings.BotAuthObject?.Access_Token, _appSettings.BotAuthObject?.Refresh_Token,
				_appSettings.BroadcasterAuthObject?.Access_Token, _appSettings.BroadcasterAuthObject?.Refresh_Token,
				_appSettings.StreamElements?.Token, _appSettings.StreamlabsClientId,
				_appSettings.StreamlabsClientSecret, _appSettings.StreamlabsInformation?.StreamlabsAToken,
				_appSettings.StreamlabsInformation?.StreamlabsSocketToken, _appSettings.HypeRateApiKey,
				_appSettings.BotName, _appSettings.ChannelName
			}.Concat((_appSettings.NanoSettings?.NanoLeafDevices ?? new List<NanoLeafDevice>()).Select(device => device.Token));
			foreach (string secret in secrets.Where(value => !string.IsNullOrWhiteSpace(value) && value.Length >= 4).Distinct())
				sanitized = sanitized.Replace(secret, "[REDACTED]", StringComparison.Ordinal);
			string userProfile = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);
			if (!string.IsNullOrWhiteSpace(userProfile))
				sanitized = sanitized.Replace(userProfile, "%USERPROFILE%", StringComparison.OrdinalIgnoreCase);
			sanitized = Regex.Replace(sanitized, @"(?i)(Bearer\s+)[A-Za-z0-9._~+/=-]+", "$1[REDACTED]");
			sanitized = Regex.Replace(sanitized, @"(?i)((?:access|refresh)[_ -]?token|api[_ -]?key|client[_ -]?secret|authorization|jwt)(\s*[:=]\s*)([^\s,;]+)", "$1$2[REDACTED]");
			return sanitized;
		}

		private void ConsoleAutoScroll_CheckBox_Changed(object sender, RoutedEventArgs e)
		{
			_consoleAutoScroll = consoleAutoScroll_CheckBox.IsChecked == true;
			if (_consoleAutoScroll)
				UpdateScrollBar(console_ListBox);
		}

		private void ChatConsole_TabControl_SelectionChanged(object sender, SelectionChangedEventArgs e)
		{
			var item = (TabItem)chatconsole_TabControl.SelectedItem;

			if (item == null)
				return;

			if (item.Name == "chat_Tabitem")
			{
				UpdateScrollBar(twitchChat_ListBox);
			}
			else if (_consoleAutoScroll)
			{
				UpdateScrollBar(console_ListBox);
			}
		}

		private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
		{
			if (_shutdownCompleted) return;
			try
			{
				if (_settingsDirty && e != null)
				{
					MessageBoxResult result = MessageBox.Show(Text("P25_Unsaved_Close"), Text("P25_Unsaved_Title"),
						MessageBoxButton.YesNoCancel, MessageBoxImage.Question);
					if (result == MessageBoxResult.Cancel)
					{
						e.Cancel = true;
						return;
					}
					if (result == MessageBoxResult.Yes)
					{
						ParseValuesIntoAppSettings();
						SaveWindowPlacement();
						_appSettingsController.SaveSettings(_appSettings);
						MarkSettingsSaved();
					}
				}
				else
				{
					ReadStreamElementsControls();
					SaveWindowPlacement();
					_appSettingsController.SaveSettings(_appSettings);
				}
				_streamElementsController?.Dispose();
				_shutdownCompleted = true;
			}
			catch (Exception ex)
			{
				_logger.Warn("Could not close StreamElements cleanly.", ex);
			}
		}

		private void Application_Exit(object sender, ExitEventArgs e)
		{
		}

		private void autoIPRefresh_Checkbox_Click(object sender, RoutedEventArgs e)
		{
			if (autoIPRefresh_Checkbox.IsChecked == true)
			{
				_appSettings.AutoIpRefresh = true;
			}
			else
			{
				_appSettings.AutoIpRefresh = false;
			}
		}

		private void NanoCooldown_TextBox_TextInput(object sender, System.Windows.Input.TextCompositionEventArgs e)
		{
			if (int.TryParse(nanoCooldown_TextBox.Text, out int cooldown) && cooldown >= 0)
				_appSettings.NanoSettings.Cooldown = cooldown;
		}

		private void NanoCooldown_TextBox_LostFocus(object sender, RoutedEventArgs e)
		{
			if (!int.TryParse(nanoCooldown_TextBox.Text, out int cooldown) || cooldown < 0)
			{
				cooldown = 0;
				nanoCooldown_TextBox.Text = "0";
			}
			_appSettings.NanoSettings.Cooldown = cooldown;
		}

		private void NanoCooldown_Checkbox_Click(object sender, RoutedEventArgs e)
		{
			_appSettings.NanoSettings.CooldownEnabled = nanoCooldown_Checkbox.IsChecked == true;
			if (!int.TryParse(nanoCooldown_TextBox.Text, out int cooldown) || cooldown < 0)
			{
				cooldown = 0;
				nanoCooldown_TextBox.Text = "0";
			}
			_appSettings.NanoSettings.Cooldown = cooldown;

			if (_appSettings.NanoSettings.CooldownEnabled)
			{
				SendChatResponse(string.Format(Properties.Resources.Code_Main_ChatMessage_CooldownON, _appSettings.NanoSettings.Cooldown));
				nanoCooldownIgnore_Checkbox.IsEnabled = true;
				_logger.Info("Cooldown enabled!");
				nanoCooldown_TextBox.IsEnabled = false;
			}
			else
			{
				SendChatResponse(Properties.Resources.Code_Main_ChatMessage_CooldownOFF);
				nanoCooldownIgnore_Checkbox.IsEnabled = false;
				_logger.Info("Cooldown disabled!");
				nanoCooldown_TextBox.IsEnabled = true;
			}
		}

		private void Response_CheckBox_Click(object sender, RoutedEventArgs e)
		{
			_appSettings.ChatResponse = (bool)response_CheckBox.IsChecked;
		}

		private void KeywordRestore_Checkbox_Click(object sender, RoutedEventArgs e)
		{
			_appSettings.NanoSettings.ChangeBackOnKeyword = (bool)keywordRestore_Checkbox.IsChecked;
		}

		private void CommandRestore_CheckBox_Click(object sender, RoutedEventArgs e)
		{
			_appSettings.NanoSettings.ChangeBackOnCommand = (bool)commandRestore_CheckBox.IsChecked;
		}

		private void AutoRestoreHelp_Button_Click(object sender, RoutedEventArgs e)
		{
			ShowHelp(HelpTopic.Nano);
		}

		private void EventReset_Button_Click(object sender, RoutedEventArgs e)
		{
			_triggerLogicController.ResetEventQueue();
		}

		private void EventRestart_Button_Click(object sender, RoutedEventArgs e)
		{
			_triggerLogicController.RestartEventQueue();
		}

		private void Responses_Button_Click(object sender, RoutedEventArgs e)
		{
			ShowEmbeddedResponses();
		}

		private void ShowEmbeddedResponses()
		{
			if (_embeddedResponses == null)
			{
				_embeddedResponses = new Responses(_appSettings, _appSettingsController);
				UIElement content = _embeddedResponses.Content as UIElement;
				_embeddedResponses.Content = null;
				_embeddedResponses.Tag = content;
				_embeddedResponses.ConfigureEmbedded(() => ShowMainPage(2),
					() => ShowHelp(HelpTopic.ChatResponses, RestoreEmbeddedResponses));
			}
			else _embeddedResponses.RefreshContent();
			ShowManagementContent(_embeddedResponses.Tag as UIElement, 2);
		}

		private void RestoreEmbeddedResponses() =>
			ShowManagementContent(_embeddedResponses?.Tag as UIElement, 2);

		private void AutoConnect_Checkbox_Click(object sender, RoutedEventArgs e)
		{
			if (autoConnect_Checkbox.IsChecked == true)
			{
				_appSettings.AutoConnect = true;
				CheckNanoDevices();
			}
			else
			{
				_appSettings.AutoConnect = false;
			}
		}

		private void ShowDevices_Button_Click(object sender, RoutedEventArgs e)
		{
			_logger.Info("Show Device Info");
			ShowEmbeddedDevices();
		}

		private void ShowEmbeddedDevices()
		{
			if (_embeddedDevices == null)
			{
				_embeddedDevices = new DevicesInfoWindow(_nanoController, _appSettings, _appSettingsController);
				UIElement content = _embeddedDevices.Content as UIElement;
				_embeddedDevices.Content = null;
				_embeddedDevices.Tag = content;
				_embeddedDevices.ConfigureEmbedded(() => ShowMainPage(1),
					() => ShowEmbeddedDeviceGroups(ShowEmbeddedDevices),
					() => ShowHelp(HelpTopic.Devices, RestoreEmbeddedDevices));
			}
			else
			{
				_embeddedDevices.InitializeData();
			}
			ShowManagementContent(_embeddedDevices.Tag as UIElement, 1);
		}

		private void RestoreEmbeddedDevices() =>
			ShowManagementContent(_embeddedDevices?.Tag as UIElement, 1);

		public void ShowEmbeddedDeviceGroups(Action returnAction = null)
		{
			if (_embeddedDeviceGroups == null)
			{
				_embeddedDeviceGroups = new DeviceGroupsWindow(_appSettings, _appSettingsController);
				UIElement content = _embeddedDeviceGroups.Content as UIElement;
				_embeddedDeviceGroups.Content = null;
				_embeddedDeviceGroups.Tag = content;
			}
			_embeddedDeviceGroups.ConfigureEmbedded(returnAction ?? ShowEmbeddedDevices,
				() => ShowHelp(HelpTopic.Devices, RestoreEmbeddedDeviceGroups));
			_embeddedDeviceGroups.RefreshContent();
			ShowManagementContent(_embeddedDeviceGroups.Tag as UIElement, 1);
		}

		private void RestoreEmbeddedDeviceGroups() =>
			ShowManagementContent(_embeddedDeviceGroups?.Tag as UIElement, 1);

		private void ShowManagementContent(UIElement content, int navigationPage)
		{
			if (content == null) return;
			management_Host.Content = content;
			chatconsole_TabControl.Visibility = Visibility.Collapsed;
			settings_TabControl.Visibility = Visibility.Collapsed;
			integrationTabs_Panel.Visibility = Visibility.Collapsed;
			triggerManager_Host.Visibility = Visibility.Collapsed;
			appInfo_Host.Visibility = Visibility.Collapsed;
			blocklistPanel.Visibility = Visibility.Collapsed;
			helpPanel.Visibility = Visibility.Collapsed;
			Save_Button.Visibility = Visibility.Collapsed;
			management_Host.Visibility = Visibility.Visible;
			_currentPage = navigationPage;
			UpdateNavigationState(navigationPage);
		}

		private void FaqLink_Button_Click(object sender, RoutedEventArgs e)
		{
			Process.Start("https://nanotwitchleafs.de/faq/");
		}

		private async void ResetBrightness_Button_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				int brightness = Convert.ToInt32(brightnessReset_TextBox.Text);
				if (brightness < 0 || brightness > 100)
				{
					MessageBox.Show(Properties.Resources.Code_Main_MessageBox_Value0100, Properties.Resources.General_MessageBox_Error_Title);
					return;
				}

				foreach (NanoLeafDevice device in _appSettings.NanoSettings.NanoLeafDevices)
				{
					await _nanoController.SetBrightness(device, brightness);
					_logger.Info($"Reset Brightness of Device {device.PublicName} to {brightness}% ");
				}
			}
			catch
			{
				MessageBox.Show(Properties.Resources.Code_Main_MessageBox_Value0100, Properties.Resources.General_MessageBox_Error_Title);
				_logger.Error("Value has to be between 0 and 100!");
			}
		}

		private void commandPrefix_TextBox_LostFocus(object sender, RoutedEventArgs e)
		{
			if (String.IsNullOrWhiteSpace(commandPrefix_TextBox.Text))
			{
				MessageBox.Show(Properties.Resources.Code_Main_MessageBox_EmptyPrefix, Properties.Resources.General_MessageBox_Error_Title);
				_logger.Warn("CommandPrefix Box cannot be Empty!");
				commandPrefix_TextBox.Text = "!";
			}
		}

		private void NanoCooldownIgnore_Checkbox_Click(object sender, RoutedEventArgs e)
		{
			_appSettings.NanoSettings.CooldownIgnore = nanoCooldownIgnore_Checkbox.IsEnabled;
		}

		#endregion

		#region Methods

		private void ConnectToChat()
		{
			try
			{
				_chatConnectionInProgress = true;
				chatStatus_TextBlock.Text = Text("P411_Chat_Connecting");
				chatStatus_TextBlock.Visibility = Visibility.Visible;
				_twitchController.Connect(_appSettings);
				ConnectChat_Button.IsEnabled = false;
				DisconnectChat_Button.IsEnabled = false;
				sendMessage_TextBox.IsEnabled = false;
				sendMessage_Button.IsEnabled = false;
			}
			catch (Exception ex)
			{
				_chatConnectionInProgress = false;
				_logger.Error("Could not start Twitch chat connection.", ex);
				TwitchController_OnChatConnectionFailed(ex.Message);
			}
		}

		private void TwitchController_OnChatConnectionChanged(bool connected)
		{
			Dispatcher.BeginInvoke(new Action(() =>
			{
				_chatConnectionInProgress = false;
				ConnectChat_Button.IsEnabled = !connected && _appSettings.BotAuthObject != null;
				DisconnectChat_Button.IsEnabled = connected;
				sendMessage_TextBox.IsEnabled = connected;
				sendMessage_Button.IsEnabled = connected;
				chatStatus_TextBlock.Text = connected ? Text("P411_Chat_Connected") : Text("P411_Chat_Disconnected");
				chatStatus_TextBlock.Visibility = _twitchChat.Count == 0 ? Visibility.Visible : Visibility.Collapsed;
			}));
		}

		private void TwitchController_OnChatConnectionFailed(string reason)
		{
			Dispatcher.BeginInvoke(new Action(() =>
			{
				_chatConnectionInProgress = false;
				ConnectChat_Button.IsEnabled = _appSettings.BotAuthObject != null;
				DisconnectChat_Button.IsEnabled = false;
				sendMessage_TextBox.IsEnabled = false;
				sendMessage_Button.IsEnabled = false;
				chatStatus_TextBlock.Text = Text("P411_Chat_ConnectionFailed");
				chatStatus_TextBlock.Visibility = Visibility.Visible;
				ShowToast(Text("P411_Chat_ConnectionFailed"));
			}));
		}

		private void DisconnectFromChat()
		{
			try
			{
				_twitchController.Disconnect();
				ConnectChat_Button.IsEnabled = true;
				DisconnectChat_Button.IsEnabled = false;
				sendMessage_TextBox.IsEnabled = false;
				sendMessage_Button.IsEnabled = false;
			}
			catch (Exception e)
			{
				_logger.Error(e.Message);
				_logger.Error(e);
			}
		}

		private void AppRestart()
		{
			var info = new ProcessStartInfo
			{
				Arguments = "/C ping 127.0.0.1 -n 2 && \"" + System.Reflection.Assembly.GetEntryAssembly()?.Location + "\"",
				WindowStyle = ProcessWindowStyle.Hidden,
				CreateNoWindow = true,
				FileName = "cmd.exe"
			};
			Process.Start(info);
			this.Close();
		}

		private bool CheckForDuplicateWindow(Window newWindow)
		{
			var count = 0;
			foreach (Window window in App.Current.Windows)
			{
				if (window.Name == newWindow.Name)
				{
					count++;
				}
			}

			return count != 1;
		}

		private void ChangeEnabledUi()
		{
			if (_appSettings.NanoSettings.NanoLeafDevices.Count != 0)
			{
				nanoTestConnection_Button.IsEnabled = true;
			}
			else
			{
				nanoTestConnection_Button.IsEnabled = false;
			}

			if (_appSettings.AutoConnect)
			{
				autoConnect_Checkbox.IsChecked = true;
			}
			else
			{
				autoConnect_Checkbox.IsChecked = false;
			}

			if (_appSettings.NanoSettings.CooldownEnabled)
			{
				nanoCooldown_TextBox.IsEnabled = false;
			}

			StreamlabsClientId_Textbox.IsEnabled = true;
			StreamlabsClientSecret_Textbox.IsEnabled = true;
			HypeRateApiKey_Textbox.IsEnabled = true;

			help_TextBlock.Text = string.Format(Properties.Resources.Code_Main_Label_NanoHelpText, _appSettings.CommandPrefix);
			generalCommandHelp_TextBlock.Text = string.Format(Properties.Resources.Code_Main_Label_NanoHelpText, _appSettings.CommandPrefix);
		}

		private void _twitchController_OnConsoleMessageReceived(string message)
		{
			_logger.Info(message);
		}

		private void _twitchController_OnChatMessageReceived(ChatMessage chatMessage)
		{
			string formattedMessage = $"{DateTime.Now.ToLongTimeString()}: {chatMessage.Username} - {chatMessage.Message}";

			twitchChat_ListBox.Dispatcher.Invoke(() =>
			{
				_twitchChat.Add(formattedMessage);
				chatStatus_TextBlock.Visibility = Visibility.Collapsed;
				twitchChat_ListBox.Items.Refresh();
				UpdateScrollBar(twitchChat_ListBox);
			});
		}

		private void SendChatResponse(string message)
		{
			if (!_appSettings.ChatResponse || _twitchController == null || string.IsNullOrWhiteSpace(message))
			{
				return;
			}

			_twitchController.SendMessageToChat(message);
		}

		private void SetLogLevel(Level logLevel)
		{
			((Hierarchy)LogManager.GetRepository()).Root.Level = logLevel;
			((Hierarchy)LogManager.GetRepository()).RaiseConfigurationChanged(EventArgs.Empty);
		}

		private async Task<bool> TestNanoConnection()
		{
			nanoInfo_TextBox.IsEnabled = true;
			nanoInfo_TextBox.Text = "";
			int deviceCount = _appSettings.NanoSettings.NanoLeafDevices.Count;
			if (deviceCount > 1)
			{
				nanoInfo_TextBox.VerticalScrollBarVisibility = ScrollBarVisibility.Auto;
				nanoInfo_TextBox.IsReadOnly = true;
			}
			foreach (var device in _appSettings.NanoSettings.NanoLeafDevices)
			{
				if (string.IsNullOrEmpty(device.Address) || string.IsNullOrWhiteSpace(device.Address))
				{
					_logger.Error(Properties.Resources.Code_Main_MessageBox_ConTestFail + " " + Properties.Resources.Code_Main_MessageBox_AdressNull + " " + Properties.Resources.Code_Main_MessageBox_UpdateOrRepair);
					MessageBox.Show(Properties.Resources.Code_Main_MessageBox_ConTestFail + " " + Properties.Resources.Code_Main_MessageBox_AdressNull + " " + Properties.Resources.Code_Main_MessageBox_UpdateOrRepair, Properties.Resources.General_MessageBox_Error_Title);
					return false;
				}

				try
				{
					var controllerInfo = await _nanoController.GetControllerInfo(device);

					if (controllerInfo == null)
					{
						_logger.Error(string.Format(Properties.Resources.Code_Main_MessageBox_ConTestFail + " " + Properties.Resources.Code_Main_MessageBox_ControllerInfoNull, device.DeviceName));
						MessageBox.Show(Properties.Resources.Code_Main_MessageBox_ConTestFail + " " + Properties.Resources.Code_Main_MessageBox_ControllerInfoNull, Properties.Resources.General_MessageBox_Error_Title);
						return false;
					}

					if (_appSettings.NanoSettings.TriggerEnabled)
					{
						nanoCmd_Button.IsEnabled = true;
					}
					else
					{
						nanoCmd_Button.IsEnabled = false;
					}

					nanoInfo_TextBox.Text += $"Name: {device.PublicName}" + Environment.NewLine;
					nanoInfo_TextBox.Text += $"Model: {controllerInfo.model}" + Environment.NewLine;
					nanoInfo_TextBox.Text += $"Serial Number: {controllerInfo.serialNo}" + Environment.NewLine;
					nanoInfo_TextBox.Text += $"Firmware Version: {controllerInfo.firmwareVersion}" + Environment.NewLine;
					nanoInfo_TextBox.Text += $"Is On: {controllerInfo.state.on.value}" + Environment.NewLine;
					nanoInfo_TextBox.Text += $"Number of Panels: {controllerInfo.panelLayout.layout.numPanels}"+ Environment.NewLine;
					nanoInfo_TextBox.Text += $"Current Effect: {controllerInfo.effects.select}" + Environment.NewLine;
					nanoInfo_TextBox.Text += $"--------------------------------" + Environment.NewLine;

					deviceCount--;
					if (controllerInfo.effects.select == "*Shuffle*" || controllerInfo.effects.select == "*Dynamic*")
					{
						MessageBox.Show(Properties.Resources.Code_Main_MessageBox_UndefinedEffect, Properties.Resources.Code_Main_MessageBox_UndefinedEffect_Title);
						_logger.Warn(Properties.Resources.Code_Main_MessageBox_UndefinedEffect);
					}

					device.NanoleafControllerInfo = controllerInfo;
				}
				catch (Exception ex)
				{
					MessageBox.Show(Properties.Resources.Code_Main_MessageBox_ConFail, Properties.Resources.General_MessageBox_Error_Title);

					_logger.Error(ex.Message, ex);
					return false;
				}
			}

			nanoInfo_TextBox.Text += $"Devices Total: {_appSettings.NanoSettings.NanoLeafDevices.Count}" + Environment.NewLine;

			_appSettingsController.SaveSettings(_appSettings);

			return true;
		}

		private bool CheckNanoDevices()
		{
			if (_appSettings.NanoSettings.NanoLeafDevices.Count == 0)
			{
				MessageBox.Show(Properties.Resources.Code_Main_MessageBox_NoDevice, Properties.Resources.General_MessageBox_Error_Title);
				_appSettings.AutoConnect = false;
				autoConnect_Checkbox.IsChecked = false;
				return false;
			}

			return true;
		}

		private async void AutoConnect()
		{
			if (!CheckNanoDevices())
			{
				_logger.Warn("[Auto Connection] Error in NanoLeaf Settings!");
				return;
			}

			_logger.Info("[Auto Connection] NanoLeaf Settings ... OK");
			_logger.Info("[Auto Connection] Try NanoLeaf Pairing ...");

			if (!await TestNanoConnection())
			{
				_logger.Error("[Auto Connection] Couldn't connect to NanoLeaf Device!");
				return;
			}

			_logger.Info("[Auto Connection] NanoLeaf Paring ... OK");
			_logger.Info("[Auto Connection] Try to connect to HypeRate ...");

			if (!string.IsNullOrWhiteSpace(_appSettings.HypeRateId) && !await TestHypeRateConnection())
			{
				_logger.Error("[Auto Connection] Could not connect to HypeRateIO ... ");
				return;
			}
			HypeRateConnect_Button.IsEnabled = false;
			HypeRateDisconnect_Button.IsEnabled = true;

			_logger.Info("[Auto Connection] Connected to HypeRateIO ... OK");
			_logger.Info("[Auto Connection] Try to connect to Streamlabs ...");

			if (!string.IsNullOrWhiteSpace(_appSettings.StreamlabsInformation.StreamlabsSocketToken) && !await TestStreamlabsConnection())
			{
				_logger.Error("[Auto Connection] Could not connect to Streamlabs ... ");
				return;
			}

			StreamlabsConnectButton.IsEnabled = false;
			StreamlabsDisconnectButton.IsEnabled = true;

			_logger.Info("[Auto Connection] Try to connect to Twitch ...");

			ConnectToChat();
		}

		private async Task<bool> TestStreamlabsConnection()
		{
			_streamlabsController.ConnectSocket();

			await Task.Delay(1000 * 1);

			return _streamlabsController._IsSocketConnected;
		}

		private async Task<bool> TestHypeRateConnection()
		{
			_hypeRatecontroller.StartListener();

			await Task.Delay(1000 * 1);

			return _hypeRatecontroller._isConnected;
		}

#if NTL4
		private JsonTriggerController CreateNtl4TriggerStore()
		{
			var jsonStore = new JsonTriggerController(Constants.TRIGGERS_PATH);
			if (jsonStore.Exists || !File.Exists(Constants.LEGACY_MIGRATION_ACCEPTED_PATH))
			{
				return jsonStore;
			}

			try
			{
				if (File.Exists(Constants.LEGACY_DATABASE_PATH))
				{
					_logger.Info("Import triggers from the existing NanoTwitchLeafs 3.x database.");
					var legacyStore = new DatabaseController<TriggerSetting>(Constants.LEGACY_DATABASE_PATH);
					var legacyTriggers = legacyStore.Load();

					if (legacyTriggers.Count == 0)
					{
						jsonStore.ClearTable();
					}
					else
					{
						foreach (TriggerSetting trigger in legacyTriggers)
						{
							jsonStore.Save(trigger);
						}
					}

					_logger.Info($"Imported {legacyTriggers.Count} triggers into local JSON storage.");
				}

				File.WriteAllText(Constants.LEGACY_MIGRATION_COMPLETED_PATH, DateTime.UtcNow.ToString("O"));
				File.Delete(Constants.LEGACY_MIGRATION_ACCEPTED_PATH);
			}
			catch (Exception exception)
			{
				_logger.Error("Could not import the existing NanoTwitchLeafs 3.x trigger database.", exception);
				MessageBox.Show(
					Properties.Resources.ResourceManager.GetString("Code_Main_MessageBox_TriggerMigration_Error"),
					Properties.Resources.ResourceManager.GetString("Code_Main_MessageBox_TriggerMigration_Title"),
					MessageBoxButton.OK,
					MessageBoxImage.Warning);
			}
			return jsonStore;
		}
#endif

		#endregion
    }
}
